import React from 'react'

function NotFound() {
  return (
    <div>
        404 <br></br>
        NotFound
    </div>
  )
}

export default NotFound
